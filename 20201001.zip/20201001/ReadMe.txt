1> Edit \SyncOrderBridge\conf\config.ini
	[MT4]
	server=  mt4 server address
	login= mt4 admin login id
	password= mt4 admin login password
	
	[DATABASE]
	db_host= ams db host
	db_port= ams db port
	db_schema= ams db schema
	db_username= ams db user
	db_password= ams db password
	
	[SYSTEM]
	sync_interval=sync interval time, in miliseconds
	mt4_timezone=mt4 timezone GMT
	local_timezone=local timezone GMT
	while_label=while label for load ignore groups

2> Edit \SyncOrderBridge\conf\log.cfg
	LogPerfix:   prefix of log file name
	FileLogPath: path to log file
	LogLevels:   log level (DEBUG, INFO, WARNING, ERROR, FATAL).
	AppendConsole: true

3> Run (open command pomp in folder \SyncOrderBridge\ or \MT5AmsBridgeDemo\)
	nfx-mt4-sync-orders.exe -console
